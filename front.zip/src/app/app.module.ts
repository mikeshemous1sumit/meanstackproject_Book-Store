import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './pages/header/header.component';
import { FooterComponent } from './pages/footer/footer.component';
import { AboutComponent } from './pages/about/about.component';
import { SliderComponent } from './pages/slider/slider.component';
import { ShopComponent } from './pages/shop/shop.component';
import { CatsidebarComponent } from './pages/catsidebar/catsidebar.component';
import { DefaultComponent } from './pages/default/default.component';
import {HttpClientModule} from '@angular/common/http';
import { CatproComponent } from './pages/catpro/catpro.component';
import { ContactComponent } from './pages/contact/contact.component';
import { ProductdetailComponent } from './pages/shop/productdetail/productdetail.component';
import { AddtcartComponent } from './pages/addtcart/addtcart.component';
import { SearchComponent } from './pages/search/search.component';
import { LoginComponent } from './pages/login/login.component';
import { PlaceComponent } from './pages/place/place.component';
import { MyorderComponent } from './pages/myorder/myorder.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    AboutComponent,
    SliderComponent,
    ShopComponent,
    CatsidebarComponent,
    DefaultComponent,
    CatproComponent,
    ContactComponent,
    ProductdetailComponent,
    AddtcartComponent,
    SearchComponent,
    LoginComponent,
    PlaceComponent,
    MyorderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
       ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
