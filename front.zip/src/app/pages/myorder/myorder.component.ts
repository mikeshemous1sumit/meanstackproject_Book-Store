import { Component, OnInit } from '@angular/core';
import {CategoryService} from 'src/app/services/category.service';

@Component({
  selector: 'app-myorder',
  templateUrl: './myorder.component.html',
  styleUrls: ['./myorder.component.css']
})
export class MyorderComponent implements OnInit {
	resData;
	data;
   sum;
   userId;
   addData;
  constructor(private catser:CategoryService) { }

  ngOnInit() {
  	this.catser.order()
  	.subscribe(res=>{
  		this.resData=res;
  		this.data=this.resData.data;
      this.sum=this.resData.sum;
      console.log(this.sum);
  	})

  }

}
