import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import {CategoryService} from 'src/app//services/category.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
	 myForm:FormGroup;
	 resData;
	 msg;

  constructor(private fb:FormBuilder,private catser:CategoryService) {}

  send(){
  	let formData=this.myForm.getRawValue();
  	this.catser.sendfeedback(formData).
  	subscribe(res=>{
  		this.resData=res;
  		if (this.resData.err==0){
  			this.msg=this.resData.msg;
  			Swal.fire('Thanks','Feedback send successfully','success');
  		}

  	})
  }

  ngOnInit() {
  	this.validate();
  }
  validate(){
  this.myForm=this.fb.group({
       'name':['',Validators.required],
       'email':['',Validators.required],
       'message':['',Validators.required],
       'subject':['',Validators.required]
     })
  }

}
