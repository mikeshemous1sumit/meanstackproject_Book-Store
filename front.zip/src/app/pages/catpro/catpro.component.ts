import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import {CategoryService} from '../../services/category.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-catpro',
  templateUrl: './catpro.component.html',
  styleUrls: ['./catpro.component.css']
})
export class CatproComponent implements OnInit {

  constructor(private ar:ActivatedRoute,private catser:CategoryService) { }
  resData;
  proData;
  category;
  id;
  userId;

  addCart(id){
    this.userId=localStorage.getItem('userId');
    if (this.userId==undefined)
      Swal.fire('oops','Please login for shoppping','error');
    else{
    this.id=id;
    this.userId=localStorage.getItem('userId');
     this.catser.addcart({'id':this.id,'userId':this.userId})
        .subscribe(res=>
          {
       this.resData=res;
       console.log(res);
        Swal.fire('Item added into cart','Please go to cart for shopping','success');    
          })
  }
}

  ngOnInit() {
  	 this.ar.params.subscribe(par=>
      {
        this.category=par.cn;
        console.log(this.category);
        this.catser.fetchproduct(this.category)
        .subscribe(res=>
          {
         this.resData=res;
          	this.proData=this.resData.pdata;
          	console.log(this.proData);
          })
      })
  	}

}
