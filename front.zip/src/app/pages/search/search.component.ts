import { Component, OnInit } from '@angular/core';
import {CategoryService} from 'src/app/services/category.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

resData;
searchData;
userId;
id;
  constructor(private catser:CategoryService) { }

    addCart(id){
    this.userId=localStorage.getItem('userId');
    if (this.userId==undefined)
      Swal.fire('oops','Please login for shoppping','error');
    else{
    this.id=id;
    this.userId=localStorage.getItem('userId');
     this.catser.addcart({'id':this.id,'userId':this.userId})
        .subscribe(res=>
          {
       this.resData=res;
       console.log(res);
        Swal.fire('Item added into cart','Please go to cart for shopping','success');    
          })
  }
}

  ngOnInit() {
  	let pname=localStorage.getItem('searchname');
  	 this.catser.getProductsearch(pname)
  	.subscribe(res=>{
  		this.resData=res;
     this.searchData=this.resData.data;
     console.log(this.searchData);
  	})
  }

}
