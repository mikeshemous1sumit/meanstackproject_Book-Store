import { Component, OnInit } from '@angular/core';
import {CategoryService} from 'src/app/services/category.service';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import {Router} from '@angular/router';

@Component({
  selector: 'app-place',
  templateUrl: './place.component.html',
  styleUrls: ['./place.component.css']
})
export class PlaceComponent implements OnInit {

respnseData;
cdata;
userId;
confirmation;
myForm:FormGroup;
  constructor(private catser:CategoryService,private fb:FormBuilder,private router:Router) { }

  confirm(){
    this.confirmation="abc";
    this.userId=localStorage.getItem('userId');
    this.catser.placeorder(this.userId)
    .subscribe(res=>{
    console.log(res);
    })

    let name=this.myForm.controls.name.value;
    let address=this.myForm.controls.address.value;
    let district=this.myForm.controls.district.value;
    let pin=this.myForm.controls.pin.value;
    let number=this.myForm.controls.number.value;

    this.catser.confirmorder({'name':name,'address':address,'district':district,'pin':pin,'number':number,'userId':this.userId})
    .subscribe(res=>{
     Swal.fire('Congratulations','Your Order has been confirmed','success');
     this.router.navigate(['/shop']);
    })  
  }

  ngOnInit() {
    this.validate();
  
  }

    validate(){
  this.myForm=this.fb.group({
       'name':['',Validators.required],
       'address':['',Validators.required],
       'district':['',Validators.required],
       'pin':['',Validators.required],
       'number':['',Validators.required]
     })
  }

}
