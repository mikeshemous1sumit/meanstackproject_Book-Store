import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddtcartComponent } from './addtcart.component';

describe('AddtcartComponent', () => {
  let component: AddtcartComponent;
  let fixture: ComponentFixture<AddtcartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddtcartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddtcartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
