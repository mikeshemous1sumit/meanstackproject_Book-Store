import { Component, OnInit } from '@angular/core';
import {CategoryService} from 'src/app/services/category.service';
import {ActivatedRoute} from '@angular/router';
import Swal from 'sweetalert2';
import {Router} from '@angular/router';

@Component({
  selector: 'app-addtcart',
  templateUrl: './addtcart.component.html',
  styleUrls: ['./addtcart.component.css']
})
export class AddtcartComponent implements OnInit {

resData;
cartData;
Q
id;
qData;
totalData;
feedback;
sum;
bill;
userId;
  constructor(private ar:ActivatedRoute,private catser:CategoryService,private router:Router) { }

  addQuantity(pname,event){
    
    this.userId=localStorage.getItem('userId');
    this.catser.addquantity({'pname':pname,'value':event.target.value,'id':this.userId})
    .subscribe(res=>{
      this.qData=res;
      console.log(this.qData);
    })
  }

  total(){
    this.userId=localStorage.getItem('userId');
    this.feedback="abc";
    this.catser. total(this.userId)
    .subscribe(res=>{
      this.totalData=res;
      this.bill=this.totalData.data;
      this.sum=this.totalData.sum;
    })
  }


  remove(id){
    this.catser.remove(id)
    .subscribe(res=>{
      Swal.fire('','Deleted','success');
      document.location.reload(true);
      this.router.navigate(['/shop/cart']);
    })
  }


  ngOnInit() {
    this.userId=localStorage.getItem('userId');
  this.catser.getcartdata(this.userId)
  .subscribe(res=>
  {
  	this.resData=res;
  	if (this.resData.err==0){
  		this.cartData=this.resData.data;
  		console.log(this.cartData);
  	}
  })
  }

}
