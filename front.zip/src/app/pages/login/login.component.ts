import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,Validators} from '@angular/forms';
import { LoginService } from 'src/app/services/login.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
	myForm:FormGroup;
	myForm1:FormGroup;
 feedback;
 msg;
 userId;
 errMsg;
 resData;
 account;
  constructor(private fb:FormBuilder,private lser:LoginService,private router:Router) { }

  login(){

     let formData=this.myForm.getRawValue();
  this.lser.adminLoginData(formData)
   .subscribe(res=>{
    this.resData=res;
    if(this.resData.err==0){
      console.log(this.resData);
    localStorage.setItem('userId',this.resData.user[0].email);
    localStorage.setItem('name',this.resData.user[0].name);
      this.router.navigate(['/']);
      document.location.reload(true);
    }
    else if (this.resData.err==1){
      Swal.fire('oops','email or password is not correct','error');
    }
  },err=>{
  console.log("api error");
  })
  }

  signup(){
    let formData=this.myForm1.getRawValue();
    let p=this.myForm1.controls.signpass.value;
    let cp=this.myForm1.controls.conpass.value;
    if (p!=cp){
      this.feedback="abc";
      this.msg="Confirm password is not matched";
    }
    else{
    this.lser.signup(formData)
    .subscribe(res=>{
     console.log(res);
    })

  }
}

create(){
  this.account="abc";
}

loginaccount(){
  this.account=null;
}

  ngOnInit() {
  	this.validate();
  	this.validate1();
  }
validate()
   {
     this.myForm=this.fb.group({
       'email':['',Validators.required],
       'logpass':['',Validators.required]
     })
   }

   validate1()
   {
     this.myForm1=this.fb.group({
       'name':['',Validators.required],
       'email':['',Validators.required],
       'signpass':['',Validators.required],
       'conpass':['',Validators.required],
       'mobileno':['',Validators.required]
     })
   }

}
