import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './pages/header/header.component';
import { FooterComponent } from './pages/footer/footer.component';
import { AboutComponent } from './pages/about/about.component';
import { SliderComponent } from './pages/slider/slider.component';
import { ShopComponent } from './pages/shop/shop.component';
import { CatsidebarComponent } from './pages/catsidebar/catsidebar.component';
import { DefaultComponent } from './pages/default/default.component';
import { CatproComponent } from './pages/catpro/catpro.component';
import { ContactComponent } from './pages/contact/contact.component';
import { ProductdetailComponent } from './pages/shop/productdetail/productdetail.component';
import { AddtcartComponent } from './pages/addtcart/addtcart.component';
import { SearchComponent } from './pages/search/search.component';
import { LoginComponent } from './pages/login/login.component';
import { PlaceComponent } from './pages/place/place.component';
import { MyorderComponent } from './pages/myorder/myorder.component';


const routes: Routes = [
{path:'header',component:HeaderComponent},
{path:'about',component:AboutComponent},
{path:'footer',component:FooterComponent},
{path:'',component:SliderComponent},
{path:'shop',component:ShopComponent,children:[
{path:'catsidebar',component:CatsidebarComponent},
{path:'',component:DefaultComponent},
{path:'catpro/:cn',component:CatproComponent},
{path:'productdetail/:id',component:ProductdetailComponent},
{path:'cart',component:AddtcartComponent},

]},
{path:'contact',component:ContactComponent},
{path:'search',component:SearchComponent},
{path:'login',component:LoginComponent},
{path:'place',component:PlaceComponent},
{path:'order',component:MyorderComponent}


];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
