import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class CategoryService {
url ="http://localhost:8086/api/";

  constructor(private http:HttpClient) { }

  getCat(){
  	return this.http.get(this.url+"getCategory");
  }
  	
  fetchproduct(cname){
  	return this.http.get(this.url+"getproduct/"+cname);
  }

sendfeedback(data){
	return this.http.post(this.url+'feedback',data);
  }

  fetchproductdetails(id){
    return this.http.get(this.url+'productdetails/'+id);
  }

  addcart(data){
    return this.http.post(this.url+'addcart',data);
  }

  getcartdata(id){
    return this.http.get(this.url+'getcartdata/'+id);
  }

  addquantity(data){
    return this.http.post(this.url+'addquantity',data);
  }

  total(id){
    return this.http.get(this.url+'total/'+id);
  }

  search(value){
    return this.http.get(this.url+'search/'+value);
  }

getProductsearch(pname){
  return this.http.get(this.url+'productsearch/'+pname);
}

remove(id){
  return this.http.get(this.url+'remove/'+id);
}

placeorder(id){
  return this.http.get(this.url+'placeorder/'+id);
}

confirmorder(data){
     return this.http.post(this.url+'confirmorder',data);
}

details(id){
  return this.http.get(this.url+'details/'+id);
}

order(){
  return this.http.get(this.url+'order');
}

showpdf(){
  return this.http.get(this.url+'show');
}

downloadpdf(pdf){
  return this.http.get(this.url+'downloadpdf/'+pdf);
}

default(){
  return this.http.get(this.url+'defaultpro');
}
}
