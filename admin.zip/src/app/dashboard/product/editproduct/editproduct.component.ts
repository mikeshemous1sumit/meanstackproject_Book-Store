import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { ActivatedRoute} from '@angular/router';
import { ProductService } from 'src/app/services/product.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editproduct',
  templateUrl: './editproduct.component.html',
  styleUrls: ['./editproduct.component.css']
})
export class EditproductComponent implements OnInit {
	myForm:FormGroup;
	p_id;
	myImage;
	id;
	editData;
	resData;

  constructor(private fb:FormBuilder,private ar:ActivatedRoute,private pser:ProductService,private router:Router) { }

editProduct(){

	 let formData=new FormData();
  formData.append('id',this.p_id);
    formData.append('pname',this.myForm.controls.pname.value);
    formData.append('description',this.myForm.controls.description.value);
      formData.append('brand',this.myForm.controls.brand.value);
        formData.append('price',this.myForm.controls.price.value);
    formData.append('Image',this.myImage);
    this.pser.editPro(formData,this.p_id)
    .subscribe(res=>
      {
        this.editData=res;
        if(this.editData.err==0){
          Swal.fire('Good Job','Product has modified suceessfully','success');
       this.router.navigate(['/dashboard/product']);
     }
      })
}

fileUpload(event)
  {
    if(event.target.files.length>0)
     {
       this.myImage=event.target.files[0];
       console.log(this.myImage);
       console.log(this.p_id);
     }
  }

  ngOnInit() {
  	this.validate();
  	 this.ar.params.subscribe(par=>
      {
        this.p_id=par.pid;
        this.pser.fetchcatById(this.p_id)
        .subscribe(res=>
          {
         this.resData=res;
         this.myForm.patchValue(this.resData.cdata[0])
          })
      })

  }


validate()
   {
     this.myForm=this.fb.group({
       'pname':['',Validators.required],
       'description':['',Validators.required],
       'brand':['',Validators.required],
       'price':['',Validators.required]
     })
   }

}
