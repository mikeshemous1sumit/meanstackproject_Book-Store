import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-orderdetail',
  templateUrl: './orderdetail.component.html',
  styleUrls: ['./orderdetail.component.css']
})
export class OrderdetailComponent implements OnInit {
resData;
res;
data;
data1;
  constructor(private lser:LoginService,private router:Router) { }

  ngOnInit() {

  	this.lser.orderdetail()
  	.subscribe(res=>{
  		this.resData=res;
  		this.data=this.resData.data;
  	})

  	this.lser.fetchproduct()
  	.subscribe(res=>{
  		this.res=res;
  		this.data1=this.res.data;
  	})
  }

}
