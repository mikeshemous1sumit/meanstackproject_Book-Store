import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { ActivatedRoute} from '@angular/router';
import { CategoryService } from 'src/app/services/category.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editcategory',
  templateUrl: './editcategory.component.html',
  styleUrls: ['./editcategory.component.css']
})
export class EditcategoryComponent implements OnInit {

  cat_id;
  id;
  resData;
  myImage;
  editData;
  myForm:FormGroup;
  constructor(private fb:FormBuilder,private ar:ActivatedRoute,private cser:CategoryService,private router:Router) { }

  editFormCategory(){

  let formData=new FormData();
  formData.append('id',this.cat_id);
    formData.append('cname',this.myForm.controls.cname.value);
    formData.append('description',this.myForm.controls.description.value);
    formData.append('Image',this.myImage);
    this.cser.editCat(formData,this.cat_id)
    .subscribe(res=>
      {
        this.editData=res;
        if(this.editData.err==0){
          Swal.fire('Good Job','Category has modified suceessfully','success');
       this.router.navigate(['/dashboard/category']);
     }
      })
 }

  fileUpload(event)
  {
    if(event.target.files.length>0)
     {
       this.myImage=event.target.files[0];
       console.log(this.myImage);
       console.log(this.cat_id);
     }
  }

  ngOnInit() {
    this.validate();
    this.ar.params.subscribe(par=>
      {
        this.cat_id=par.cid;
        this.cser.fetchcatById(this.cat_id)
        .subscribe(res=>
          {
         this.resData=res;
         this.myForm.patchValue(this.resData.cdata[0])
          })
      })
  }
   validate()
   {
     this.myForm=this.fb.group({
       'cname':['',Validators.required],
       'description':['',Validators.required]
     })
   }
}
