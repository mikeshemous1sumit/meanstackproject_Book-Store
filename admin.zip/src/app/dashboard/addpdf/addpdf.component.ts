import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CategoryService } from 'src/app/services/category.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-addpdf',
  templateUrl: './addpdf.component.html',
  styleUrls: ['./addpdf.component.css']
})
export class AddpdfComponent implements OnInit {

	 myForm:FormGroup;
  myPDF;
  myImage;
  catData;
resData;
  constructor(private fb:FormBuilder,private catser:CategoryService,private router:Router) { }

  ngOnInit() {
  	this.validate();
  }

   fileUpload(event)
  {
    if(event.target.files.length>0)
     {
       this.myPDF=event.target.files[0];
       console.log(this.myPDF);
     }
  }


  addPDF(){
  	  let formData=new FormData();
    formData.append('bname',this.myForm.controls.bname.value);
     formData.append('author',this.myForm.controls.author.value);
    formData.append('description',this.myForm.controls.description.value);
    formData.append('PDF',this.myPDF);
    console.log(formData);
    this.catser.addpdf(formData)
    .subscribe(res=>{
    Swal.fire('Good','Added Succesfully','success');
      this.router.navigate(['/dashboard/download']);
    })
  }


  validate()
  {
    this.myForm=this.fb.group(
      {
        'bname':['',Validators.required],
        'author':['',Validators.required],
        'description':['',Validators.required]
      }
    )
  }
}
