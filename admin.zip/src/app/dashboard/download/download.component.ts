import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/services/category.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-download',
  templateUrl: './download.component.html',
  styleUrls: ['./download.component.css']
})
export class DownloadComponent implements OnInit {
resData;
pdata;
  constructor(private catser:CategoryService) { }

  ngOnInit() {
  
   this.catser.show()
   .subscribe(res=>{
   	this.resData=res;
   	this.pdata=this.resData.data;
   })
  }

}
