import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CategoryService } from 'src/app/services/category.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.css']
})
export class AddcategoryComponent implements OnInit {

 myForm:FormGroup;
  myImage;
  catData;
  constructor(private fb:FormBuilder,private catser:CategoryService,private router:Router) { }

  ngOnInit() {
    this.validate();
  }
  fileUpload(event)
  {
    if(event.target.files.length>0)
     {
       this.myImage=event.target.files[0];
       console.log(this.myImage);
     }
  }
  addFormCategory()
  {
    let formData=new FormData();
    formData.append('cname',this.myForm.controls.cname.value);
    formData.append('description',this.myForm.controls.description.value);
    formData.append('Image',this.myImage);
    this.catser.addCat(formData)
    .subscribe(res=>
      {
        this.catData=res;
        if(this.catData.err==0){
          Swal.fire('','Category suceessfully added','success');
        }
       this.router.navigate(['/dashboard/category']);
      })
  }
  validate()
  {
    this.myForm=this.fb.group(
      {
        'cname':['',Validators.required],
        'description':['',Validators.required]
      }
    )
  }
}
