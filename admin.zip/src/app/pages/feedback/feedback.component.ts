import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import {Router} from '@angular/router';


@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  constructor(private lser:LoginService,private fb:FormBuilder,private router:Router) { }

  myForm:FormGroup;
resData;
data;
  send(id){
    let reply=prompt("Reply to the User");
    console.log(id+" "+reply);
    if (reply!=null){
    this.lser.send({'id':id,'reply':reply}).
    subscribe(res=>{
    })
  }
  }


  deletef(id){
    this.lser.deletefeed(id).
    subscribe(res=>{

    })
  }

  ngOnInit() {
    this.validate();

  	this.lser.feedbackshow()
  	.subscribe(res=>{
  		this.resData=res;
  		this.data=this.resData.data;
  	})
  }

   validate()
  {
    this.myForm=this.fb.group(
      {
        'reply':['',Validators.required]
      }
    )
  }

}
