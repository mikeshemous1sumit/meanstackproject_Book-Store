import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
url ="http://localhost:8086/api/";

constructor(private http:HttpClient) { }

addCat(data)
  {
    return this.http.post(this.url+'addCategory',data);
  }

  deletecategory(id)
  {
    return this.http.get(this.url+"delcat/"+id);
  }

getCat(){
	return this.http.get(this.url+'getCategory');
}

fetchcatById(id)
  {
    return this.http.get(this.url+"fetchcatbyid/"+id);
  }
  editCat(data,cat_id)
  {
    return this.http.post(this.url+'editCategory/'+cat_id,data);
  }

  addpdf(data){
    return this.http.post(this.url+'addpdf',data);
  }

 show(){
  return this.http.get(this.url+'show');
 }


}
