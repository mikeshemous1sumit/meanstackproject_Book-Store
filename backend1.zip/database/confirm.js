const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const confirm = new Schema({
  email:String,
  name:String,
  address:String,
  district:String,
  pin:Number,
  mobile:Number,
  total:Number
});
module.exports = mongoose.model('confirm',confirm);