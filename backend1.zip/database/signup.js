const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const signup = new Schema({
    name:String,
     email:String,
    password:String,
    mobile:String
});
module.exports = mongoose.model('signup',signup);