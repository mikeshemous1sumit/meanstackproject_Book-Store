import { Component, OnInit } from '@angular/core';
import {CategoryService} from 'src/app/services/category.service';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.css']
})
export class SliderComponent implements OnInit {
resData;
data;
pdf;
  constructor(private catser:CategoryService) { }

  download(pdf){
  	this.pdf=pdf;
  	this.catser.downloadpdf(this.pdf)
  	.subscribe(res=>{
        
  	})

  }

  ngOnInit() {

  	this.catser.showpdf()
  	.subscribe(res=>{
  		this.resData=res;
       this.data=this.resData.data;
  	})
  }

}
