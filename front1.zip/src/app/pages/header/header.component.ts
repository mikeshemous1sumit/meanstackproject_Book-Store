import { Component, OnInit } from '@angular/core';
import {FormGroup} from '@angular/forms';
import {CategoryService} from 'src/app/services/category.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

myForm:FormGroup;
resData;
ok;
notok;
userId;
name;
  constructor(private catser:CategoryService,private router:Router) { }

  search(values){
  	let searchvalue=values;
  	this.catser.search(searchvalue)
  	.subscribe(res=>{
         this.resData=res;
       if (this.resData.err==1){
       	let cname=this.resData.data[0].cname;
       	 this.router.navigate(['/shop/catpro/'+cname]);
       }
       else if (this.resData.err==0)
       	alert("Not found");
       else if (this.resData.err==2){
        localStorage.setItem('searchname',this.resData.data[0].pname);
        localStorage.setItem('category',this.resData.data[0].cname);
        this.router.navigate(['/search']);
       }
  	})
  }

   signOut()
   {
     localStorage.removeItem('userId');
      this.router.navigate(['/'])
      document.location.reload(true);
   }

  ngOnInit() {
    this.userId=localStorage.getItem('userId');
    this.name=localStorage.getItem('name');
    if (this.userId==undefined)
     this.ok="abc";
   else
    this.notok="abc";
  }

}
