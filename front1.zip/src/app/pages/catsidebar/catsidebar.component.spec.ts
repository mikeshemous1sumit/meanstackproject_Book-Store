import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CatsidebarComponent } from './catsidebar.component';

describe('CatsidebarComponent', () => {
  let component: CatsidebarComponent;
  let fixture: ComponentFixture<CatsidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CatsidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CatsidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
