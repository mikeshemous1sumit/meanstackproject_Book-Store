import { Component, OnInit } from '@angular/core';
import {CategoryService} from '../../services/category.service';

@Component({
  selector: 'app-catsidebar',
  templateUrl: './catsidebar.component.html',
  styleUrls: ['./catsidebar.component.css']
})
export class CatsidebarComponent implements OnInit {

  constructor(private catser:CategoryService) { }
  resData;
  catData;

  ngOnInit() {
  	this.catser.getCat()
    .subscribe(res=>
      {
         this.resData=res;
         if(this.resData.err==0)
         {
           this.catData=this.resData.cdata;
           console.log(this.catData);
         }
      })
  }

}
