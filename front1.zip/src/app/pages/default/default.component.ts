import { Component, OnInit } from '@angular/core';
import {CategoryService} from 'src/app/services/category.service';
import Swal from 'sweetalert2';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-default',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.css']
})
export class DefaultComponent implements OnInit {
defaultdata;
resData;
id;
  userId;
  constructor(private catser:CategoryService,private ar:ActivatedRoute) { }

 addCart(id){
    this.userId=localStorage.getItem('userId');
    if (this.userId==undefined)
      Swal.fire('oops','Please login for shoppping','error');
    else{
    this.id=id;
    this.userId=localStorage.getItem('userId');
     this.catser.addcart({'id':this.id,'userId':this.userId})
        .subscribe(res=>
          {
       this.resData=res;
       console.log(res);
        Swal.fire('Item added into cart','Please go to cart for shopping','success');    
          })
  }
}


  ngOnInit() {
  	this.catser.default()
  	.subscribe(res=>{
  		this.resData=res;
  		console.log(this.resData);
  		this.defaultdata=this.resData.data;
  	})
  }

}
