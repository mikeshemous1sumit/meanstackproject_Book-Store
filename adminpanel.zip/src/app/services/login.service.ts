import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
	url="http://localhost:8086/api/";

  constructor(private http:HttpClient) { }

  adminLoginData(data){
return this.http.post(this.url+'adminlogin',data);

  }
  
  changepass(data){

    return this.http.post(this.url+'changepassword',data);
  }


feedbackshow(){
	return this.http.get(this.url+'feedbackshow');
}

send(data){
  return this.http.post(this.url+'reply',data);
}

deletefeed(id){
  return this.http.get(this.url+'deletefeed/'+id);
}


orderdetail(){
  return this.http.get(this.url+'orderdetail');
}

fetchproduct(){
  return this.http.get(this.url+'fetchproduct');
}
  
  }
