import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
	url ="http://localhost:8086/api/";

  constructor(private http:HttpClient) { }

  addPro(data){
  	 return this.http.post(this.url+'addProduct',data);
  }

  getPro(){
	return this.http.get(this.url+'getProduct');
}

getFilter(d){
	return this.http.get(this.url+'getfilter/'+d);
}


  deletecategory(id)
  {
    return this.http.get(this.url+"delpro/"+id);
  }

  fetchcatById(pid)
  {
    return this.http.get(this.url+"fetchcatbypid/"+pid);
  }
  editPro(data,p_id)
  {
    return this.http.post(this.url+'editProduct/'+p_id,data);
  }



}
