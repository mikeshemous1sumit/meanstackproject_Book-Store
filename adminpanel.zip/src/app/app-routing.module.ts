import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DefaultComponent } from './dashboard/default/default.component';
import { CategoryComponent } from './dashboard/category/category.component';
import { AddcategoryComponent } from './dashboard/addcategory/addcategory.component';
import { EditcategoryComponent } from './dashboard/category/editcategory/editcategory.component';
import { ChangepasswordComponent } from './dashboard/changepassword/changepassword.component';
import { ProductComponent } from './dashboard/product/product.component';
import { AddproductComponent } from './dashboard/addproduct/addproduct.component';
import { EditproductComponent } from './dashboard/product/editproduct/editproduct.component';
import { DownloadComponent } from './dashboard/download/download.component';
import { AddpdfComponent } from './dashboard/addpdf/addpdf.component';
import { FeedbackComponent } from './pages/feedback/feedback.component';
import { OrderdetailComponent } from './dashboard/orderdetail/orderdetail.component';



const routes: Routes = [
{path:'',component:LoginComponent},
{path:'dashboard',component:DashboardComponent,children:[
   {path:'default',component:DefaultComponent},
   {path:'category',component:CategoryComponent},
   {path:'addcategory',component:AddcategoryComponent},
   {path:'editcategory/:cid',component:EditcategoryComponent},
   {path:'changepassword',component:ChangepasswordComponent},
   {path:'product',component:ProductComponent},
   {path:'addproduct',component:AddproductComponent},
   {path:'editproduct/:pid',component:EditproductComponent},
   {path:'downlaod',component:DownloadComponent},
   {path:'addpdf',component:AddpdfComponent},
   {path:'feedback',component:FeedbackComponent},
   {path:'odetail',component:OrderdetailComponent}
   ]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
