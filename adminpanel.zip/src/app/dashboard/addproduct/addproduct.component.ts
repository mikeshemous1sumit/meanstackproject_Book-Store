import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { ProductService } from 'src/app/services/product.service';
import { CategoryService } from 'src/app/services/category.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

myForm:FormGroup;
resData;
catData;
  myImage;
  proData;

  constructor(private fb:FormBuilder,private pser:ProductService,private catser:CategoryService,private  router:Router) { }


fileUpload(event)
  {
    if(event.target.files.length>0)
     {
       this.myImage=event.target.files[0];
       console.log(this.myImage);
     }
  }

  addProduct(){

   let formData=new FormData();
    formData.append('cname',this.myForm.controls.cname.value);
 formData.append('pname',this.myForm.controls.pname.value);
  formData.append('description',this.myForm.controls.description.value);
   formData.append('brand',this.myForm.controls.brand.value);
    formData.append('price',this.myForm.controls.price.value);
      formData.append('Image',this.myImage);
       this.pser.addPro(formData)
    .subscribe(res=>
      {
         this.proData=res;
        if(this.proData.err==0){
          Swal.fire('Good Job','Product suceessfully added','success');
        }
     this.router.navigate(['/dashboard/product']);
      })
  }

  ngOnInit() {
  	this.validate();

     this.catser.getCat()
    .subscribe(res=>
      {
         this.resData=res;
         if(this.resData.err==0)
         {
           this.catData=this.resData.cdata;
           console.log(this.catData);
         }
      })
  }

   validate()
   {
     this.myForm=this.fb.group({
       'pname':['',Validators.required],
       'cname':['',Validators.required],
       'description':['',Validators.required],
       'brand':['',Validators.required],
       'price':['',Validators.required]
     })
   }


}
