import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/services/category.service';
import { ProductService } from 'src/app/services/product.service';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

myForm:FormGroup;
	resData; 
  msg;
    catData;
    proData;
    Data;
    delData;
    deldata;
    d;
  constructor(private catser:CategoryService,private pser:ProductService,private fb:FormBuilder) { }

 filter(){
   
   if(this.myForm.controls.all.value=="all1"){
 this.pser.getPro()
    .subscribe(res=>
      {
         this.proData=res;
         if(this.proData.err==0)
         {
           this.Data=this.proData.data;
           console.log(this.Data);
         }
      })

   }
else{
  this.d=this.myForm.controls.all.value;
      this.pser.getFilter(this.d)
      .subscribe(res=>{
        this.proData=res;
        if(this.proData.err==0){
          this.Data=this.proData.data;
        }
      })
    }
    }
  
 delcat(id)
  {
 
  if(  confirm("Do you want to delete this category?")){
    this.pser. deletecategory(id)
    .subscribe(res=>
      {
        
        this.delData=res;
        if(this.delData.err==0)
        {

          this.msg=this.delData.msg;
          this.pser.getPro()
          .subscribe(res=>
            {
               this.delData=res;
               if(this.delData.err==0)
               {
                 this.Data=this.delData.data;
                 console.log(this.Data);
               }
            })
        }
      })
  }
}

  ngOnInit() 
  {
    this.validate();
   this.catser.getCat()
    .subscribe(res=>
      {
         this.resData=res;
         if(this.resData.err==0)
         {
           this.catData=this.resData.cdata;
           console.log(this.catData);
         }
      })

     this.pser.getPro()
    .subscribe(res=>
      {
         this.proData=res;
         if(this.proData.err==0)
         {
           this.Data=this.proData.data;
           console.log(this.Data);
         }
      })
  }
  validate()
   {
     this.myForm=this.fb.group({
       'all':['',Validators.required]
     })
   }

}
