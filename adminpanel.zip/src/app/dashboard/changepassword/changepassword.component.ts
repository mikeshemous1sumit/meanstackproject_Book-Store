import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import {LoginService} from 'src/app/services/login.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
userId;
msg;
resData;
feedback;
  myForm:FormGroup;

  constructor(private fb:FormBuilder, private lser:LoginService,private router:Router) { }

  changePass()
  {

  	
    let op=this.myForm.controls.op.value;
    let np=this.myForm.controls.np.value;
    let cp=this.myForm.controls.cp.value;

    if (np!=cp){
      this.feedback="abc";
      this.msg="Old Password and new Password are not matching.";
    }
    else{

    this.userId=localStorage.getItem('userId');
  //formData.append('email',this.userId)
   this.lser.changepass({'op':op,'np':np,'email':this.userId})
   .subscribe(res=>
   {
   
    this.resData=res;
    if (this.resData.err==1){
      Swal.fire('','Old Password is not correct','error')
    }
    else if (this.resData.err==0){
      Swal.fire('','Password has changed successfully','success');
      this.router.navigate(['/dashboard']);
   }
   })
  }
}


  ngOnInit() {
  this.validate();
  }

   validate()
   {
     this.myForm=this.fb.group({
       'op':['',Validators.required],
       'np':['',Validators.required],
       'cp':['',Validators.required]
     })
   }

}
